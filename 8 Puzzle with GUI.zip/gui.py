import pygame
import random
import time
from settings import *
from sprite import *
from main import *

def startGame():
    import time
    startState=input("Enter start state:\n")
    if(checkInput(startState)==False):
        print("Invalid input\n")
    elif(checkIfSolvable(startState)==False):
        print("Puzzle is not solvable\n")
    else:
        algo=input("Please Enter algorithm\n")
        parent_map={}
        explored=set()
        maxdepth=0
        currentState=startState
        t0=time.time()
        if(algo=="BFS"):
            parent_map,currentState,explored,maxdepth=BFS(startState,"012345678")
        elif(algo=="DFS"):
            parent_map,currentState,explored,maxdepth=DFS(startState,"012345678")
        elif(algo=="A*"):
            equ=input("Please enter equation to be used: euclidean or manhattan\n")
            if(equ=="manhattan"):
                parent_map,currentState,explored,maxdepth=A_star("manhattan",startState,"012345678")
            elif(equ=="euclidean"):
                parent_map,currentState,explored,maxdepth=A_star("euclidean",startState,"012345678")
            else:
                print("Wrong input , program will exit\n")
                sys.exit()
        else:
                print("Wrong input , program will exit\n")
                sys.exit()
        p,c=deliverables(parent_map,explored,currentState,startState)
        return p

ss = startGame()
ln = len(ss)
cState=ln-1

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(title)

    def create_game(self):
        counter = 0
        grid = []
        for x in range(GAME_SIZE):
            grid.append([])
            for y in range(GAME_SIZE):
                grid[x].append(ss[ln-1][counter])
                counter = counter+1
        return grid

    def draw_tiles(self):
        self.tiles = []
        for row, x in enumerate(self.tiles_grid):
            self.tiles.append([])
            for col, tile in enumerate(x):
                if tile != "0":
                    self.tiles[row].append(Tile(self, col, row, str(tile)))
                else:
                    self.tiles[row].append(Tile(self, col, row, "empty"))

    def new(self):
        self.all_sprites = pygame.sprite.Group()
        self.tiles_grid = self.create_game()
        self.draw_tiles()

    def run(self):
        self.playing = True
        while self.playing:
            self.events()
            time.sleep(0.5)
            self.update()
            self.draw()

    def update(self):
        global cState
        grid=[]
        counter=0
        if cState != -1:
            for x in range(GAME_SIZE):
                grid.append([])
                for y in range(GAME_SIZE):
                    grid[x].append(ss[cState][counter])
                    counter+=1
            cState-=1
        self.tiles_grid=grid
        self.draw_tiles()
        self.all_sprites.update()

    def draw_grid(self):
        for row in range(-1, GAME_SIZE * TILESIZE, TILESIZE):
            pygame.draw.line(self.screen, LIGHTGREY, (row, 0), (row, GAME_SIZE * TILESIZE))
        for col in range(-1, GAME_SIZE * TILESIZE, TILESIZE):
            pygame.draw.line(self.screen, LIGHTGREY, (0, col), (GAME_SIZE * TILESIZE, col))

    def draw(self):
        self.screen.fill(BGCOLOUR)
        self.all_sprites.draw(self.screen)
        self.draw_grid()
        pygame.display.flip()

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit(0)




game = Game()
while True:
    game.new()
    game.run()
